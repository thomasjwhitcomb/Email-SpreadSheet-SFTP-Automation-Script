# Class Scheduler and SFTP Upload

This application combines the Acuity email parser and the SFTP uploader into one desktop workflow.

## What it does

1. Paste an Acuity appointment/admin email into the Scheduler tab.
2. Parse the email into a registration record.
3. Review or edit the record.
4. Add the record to the schedule table.
5. Export the schedule table to CSV.
6. Upload that exact CSV to your SFTP server.

## Files

- `class_scheduler_app.py` - integrated desktop app
- `requirements.txt` - Python dependencies

## Install

```bash
pip install -r requirements.txt
```

## Run

```bash
python class_scheduler_app.py
```

## Notes

- The app keeps the original strict SFTP behavior:
  - password authentication
  - remote directory must already exist
  - optional size and SHA256 verification
- Passwords can be entered directly in the UI or stored in your OS keyring.
- The app saves non-secret settings in:
  - `~/.class_scheduler_sftp_app.json`

## Typical workflow

1. Open the app.
2. Paste the Acuity email into the left panel.
3. Click **Parse email**.
4. Review the extracted fields and click **Add record**.
5. Repeat for additional registrations.
6. Set the output folder and CSV filename.
7. Click **Export CSV**.
8. Go to the **SFTP Upload** tab.
9. Confirm your host, username, remote directory, and selected CSV path.
10. Click **Upload selected CSV**.

## Assumptions used in this version

- Desktop UI instead of web UI, to keep setup simple and make the tool easy to run as a single Python app.
- The scheduler is a roster builder/exporter for class registrations based on Acuity emails.
- CSV columns remain aligned with the original parser output so existing downstream workflows still work.
