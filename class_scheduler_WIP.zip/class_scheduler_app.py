#!/usr/bin/env python3
"""
Class Scheduler + SFTP Uploader

This desktop application combines the two provided scripts into one workflow:
1) Paste an Acuity appointment/admin email into the app
2) Parse the email into a structured class registration record
3) Review or edit the record, then add it to a schedule table
4) Export the schedule table to a CSV file
5) Upload that CSV file to an SFTP server

Design goals:
- Keep the UI clean and easy to use
- Preserve the parsing and upload behaviors from the original scripts
- Add enough structure so the tool can be used as a real day-to-day app
- Include comments throughout so future edits are straightforward
"""

from __future__ import annotations

import csv
import errno
import hashlib
import json
import logging
import os
import queue
import re
import threading
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional

import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from tkinter.scrolledtext import ScrolledText

# Third-party modules used by the original scripts.
# The app can still start if they are missing, but upload functionality
# (paramiko / keyring) or date parsing (dateutil) will be limited.
try:
    import paramiko
except ImportError:  # pragma: no cover - depends on local environment
    paramiko = None

try:
    import keyring
except ImportError:  # pragma: no cover - depends on local environment
    keyring = None

try:
    from dateutil import parser as dateparser
except ImportError:  # pragma: no cover - depends on local environment
    dateparser = None


APP_TITLE = "Class Scheduler and SFTP Upload"
APP_CONFIG_PATH = Path.home() / ".class_scheduler_sftp_app.json"
CSV_COLUMNS = [
    "EMAIL",
    "First Name",
    "M",
    "Last Name",
    "Phone",
    "Course",
    "Date",
    "Acuity Regist.",
]
COURSE_OPTIONS = ["", "ACLS", "BLS", "PALS"]
BOOLEAN_OPTIONS = ["YES", "NO"]
ADMIN_MARKER = "The info below is just sent to you as the admin"

# Regex patterns come from the original Acuity parsing script.
NAME_RE = re.compile(r"^Name\s*:\s*(.+)$", re.IGNORECASE | re.MULTILINE)
PHONE_RE = re.compile(r"^Phone\s*:\s*(.+)$", re.IGNORECASE | re.MULTILINE)
EMAIL_RE = re.compile(r"^Email\s*:\s*(.+)$", re.IGNORECASE | re.MULTILINE)
WHEN_RE = re.compile(r"^When\s+(.+)$", re.IGNORECASE | re.MULTILINE)


# -----------------------------
# Data models
# -----------------------------

@dataclass
class ClassRecord:
    """A single row in the class schedule / export CSV."""

    email: str = ""
    first_name: str = ""
    middle_initial: str = ""
    last_name: str = ""
    phone: str = ""
    course: str = ""
    date: str = ""
    acuity_registered: str = "YES"

    def to_csv_row(self) -> dict[str, str]:
        """Return a dict whose keys exactly match the export column order."""
        return {
            "EMAIL": self.email,
            "First Name": self.first_name,
            "M": self.middle_initial,
            "Last Name": self.last_name,
            "Phone": self.phone,
            "Course": self.course,
            "Date": self.date,
            "Acuity Regist.": self.acuity_registered,
        }

    @classmethod
    def from_csv_row(cls, row: dict[str, str]) -> "ClassRecord":
        """Build a record from a CSV row that uses the expected export columns."""
        return cls(
            email=row.get("EMAIL", "").strip(),
            first_name=row.get("First Name", "").strip(),
            middle_initial=row.get("M", "").strip(),
            last_name=row.get("Last Name", "").strip(),
            phone=row.get("Phone", "").strip(),
            course=row.get("Course", "").strip(),
            date=row.get("Date", "").strip(),
            acuity_registered=row.get("Acuity Regist.", "YES").strip() or "YES",
        )


@dataclass
class AppConfig:
    """Simple JSON-backed settings for the desktop app."""

    output_dir: str = str(Path.home())
    csv_filename: str = "class_schedule.csv"
    sftp_host: str = ""
    sftp_port: int = 22
    sftp_username: str = ""
    sftp_remote_dir: str = "/incoming"
    sftp_keyring_service: str = "rqi-sftp"
    verify_size: bool = True
    verify_sha256: bool = False
    auto_add_hostkey: bool = False
    last_upload_file: str = ""

    @classmethod
    def load(cls, path: Path = APP_CONFIG_PATH) -> "AppConfig":
        if not path.exists():
            return cls()

        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return cls(**data)
        except Exception:
            # If the config file is invalid, we do not want to block app startup.
            return cls()

    def save(self, path: Path = APP_CONFIG_PATH) -> None:
        path.write_text(json.dumps(asdict(self), indent=2), encoding="utf-8")


# -----------------------------
# Parsing helpers (adapted from acuityScraper.py)
# -----------------------------


def pick_course(text: str) -> str:
    """Infer the course name from the email text."""
    lowered = (text or "").lower()
    if "pals" in lowered:
        return "PALS"
    if "bls" in lowered:
        return "BLS"
    if "acls" in lowered:
        return "ACLS"
    return ""



def split_name(full_name: str) -> tuple[str, str, str]:
    """Split a full name into first, middle initial, and last name."""
    parts = (full_name or "").strip().split()
    if not parts:
        return "", "", ""
    if len(parts) == 1:
        return parts[0], "", ""

    first = parts[0]
    last = parts[-1]
    middle = " ".join(parts[1:-1]) if len(parts) > 2 else ""
    return first, (middle[:1] if middle else ""), last



def extract_field(regex: re.Pattern, text: str) -> str:
    """Shared helper for pulling a single labeled line from a block of text."""
    match = regex.search(text or "")
    return match.group(1).strip() if match else ""



def extract_admin_section(body: str) -> str:
    """Return the admin-only section from an Acuity email, if present."""
    if not body:
        return ""

    idx = body.lower().find(ADMIN_MARKER.lower())
    return body[idx:] if idx != -1 else ""



def extract_when_date(body: str) -> str:
    """
    Extract the class date from the 'When ...' line.

    The original script used dateutil so it could handle friendly strings such as
    'Thursday, February 26, 2026 5:00pm CST (1 hour)'. We keep that behavior here.
    """
    match = WHEN_RE.search(body or "")
    if not match:
        return ""

    when_line = match.group(1).strip()
    when_line = re.sub(r"\(.*?\)\s*$", "", when_line).strip()

    if dateparser is None:
        # Fall back to the raw line if python-dateutil is not installed.
        return when_line

    try:
        dt = dateparser.parse(when_line, fuzzy=True, ignoretz=True)
        return f"{dt.month}/{dt.day}/{str(dt.year)[-2:]}"
    except Exception:
        return when_line



def scrape_acuity_admin_fields(email_body: str) -> ClassRecord:
    """
    Parse a pasted Acuity email and return a ClassRecord.

    This mirrors the behavior of the supplied script and keeps the same exported
    fields so downstream CSV and SFTP workflows remain compatible.
    """
    admin_section = extract_admin_section(email_body)

    full_name = extract_field(NAME_RE, admin_section)
    phone = extract_field(PHONE_RE, admin_section)
    email = extract_field(EMAIL_RE, admin_section)

    course = pick_course(email_body)
    date_str = extract_when_date(email_body)

    first, middle_initial, last = split_name(full_name)

    return ClassRecord(
        email=email,
        first_name=first,
        middle_initial=middle_initial,
        last_name=last,
        phone=phone,
        course=course,
        date=date_str,
        acuity_registered="YES",
    )


# -----------------------------
# SFTP helpers (adapted from sftp_upload.py)
# -----------------------------


def sha256_file(path: str, chunk_size: int = 65536) -> str:
    """Compute a file hash without reading the whole file into memory."""
    h = hashlib.sha256()
    with open(path, "rb") as file_obj:
        for chunk in iter(lambda: file_obj.read(chunk_size), b""):
            h.update(chunk)
    return h.hexdigest()



def verify_remote_dir_exists(sftp, remote_dir: str) -> None:
    """
    Validate that the destination directory already exists.

    This intentionally does NOT create remote folders, matching the 'strict'
    behavior from the original uploader script.
    """
    if not remote_dir or remote_dir in (".", "/"):
        return

    remote_dir = remote_dir.replace("\\", "/").rstrip("/")

    try:
        sftp.stat(remote_dir)
    except IOError as exc:
        err = getattr(exc, "errno", None)

        if err == errno.ENOENT or "No such file" in str(exc):
            raise RuntimeError(
                f"Remote directory '{remote_dir}' does not exist. Upload aborted."
            ) from exc

        if err == errno.EACCES or "Permission denied" in str(exc):
            raise RuntimeError(
                f"No permission to access remote directory '{remote_dir}'. Upload aborted."
            ) from exc

        raise



def resolve_password(username: str, cli_password: str | None, keyring_service: str) -> str:
    """
    Resolve the SFTP password in the same order as the original script:
    1) password passed directly from the UI
    2) keyring lookup by service + username
    """
    if cli_password:
        return cli_password

    if keyring is None:
        raise RuntimeError(
            "Password not provided and the 'keyring' package is not installed. "
            "Install keyring or enter a password in the UI."
        )

    password = keyring.get_password(keyring_service, username)
    if not password:
        raise RuntimeError(
            "Password not provided and not found in keyring. "
            "Enter a password in the UI or store it in the OS keyring."
        )
    return password



def upload_file_with_password(
    host: str,
    port: int,
    username: str,
    password: str,
    local_path: str,
    remote_dir: str,
    verify_sha256: bool = False,
    verify_size: bool = True,
    auto_add_host_key: bool = False,
    timeout: int = 10,
) -> bool:
    """
    Upload a single file to an SFTP server using password authentication.

    The original script accepted local-dir + filename separately. In a GUI app,
    it is cleaner to work with one full local path.
    """
    if paramiko is None:
        raise RuntimeError(
            "The 'paramiko' package is not installed. Install it to enable SFTP uploads."
        )

    if not local_path or not os.path.isfile(local_path):
        raise RuntimeError(f"Local file does not exist: {local_path}")

    filename = os.path.basename(local_path)
    remote_dir = (remote_dir or "").replace("\\", "/").rstrip("/")
    if remote_dir in ("", "."):
        remote_dir = "/"

    remote_path = (remote_dir.rstrip("/") + "/" + filename) if remote_dir != "/" else ("/" + filename)

    client = paramiko.SSHClient()

    try:
        client.load_system_host_keys()
    except Exception:
        # Known hosts may not exist yet; that is okay.
        pass

    if auto_add_host_key:
        logging.warning(
            "Auto-adding unknown host keys (MITM risk). For production, use known_hosts."
        )
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    else:
        client.set_missing_host_key_policy(paramiko.RejectPolicy())

    sftp = None
    try:
        logging.info("Connecting to %s:%d as %s", host, port, username)
        client.connect(
            hostname=host,
            port=port,
            username=username,
            password=password,
            timeout=timeout,
            banner_timeout=timeout,
            look_for_keys=False,
            allow_agent=False,
        )
        logging.info("Authentication successful.")

        sftp = client.open_sftp()
        logging.info("Opened SFTP connection.")

        logging.info("Verifying remote directory: %s", remote_dir)
        verify_remote_dir_exists(sftp, remote_dir)

        logging.info("Uploading %s -> %s", local_path, remote_path)
        sftp.put(local_path, remote_path)

        if verify_size:
            local_size = os.path.getsize(local_path)
            remote_size = sftp.stat(remote_path).st_size
            logging.info("Local size: %d bytes, Remote size: %d bytes", local_size, remote_size)
            if local_size != remote_size:
                raise RuntimeError("Size mismatch after upload.")

        if verify_sha256:
            logging.info("Computing local SHA256...")
            local_hash = sha256_file(local_path)

            logging.info("Computing remote SHA256 by streaming remote file...")
            h = hashlib.sha256()
            with sftp.open(remote_path, "rb") as remote_file:
                for chunk in iter(lambda: remote_file.read(65536), b""):
                    h.update(chunk)
            remote_hash = h.hexdigest()

            logging.info("Local SHA256:  %s", local_hash)
            logging.info("Remote SHA256: %s", remote_hash)
            if local_hash != remote_hash:
                raise RuntimeError("SHA256 mismatch after upload.")

        logging.info("Upload completed and verified.")
        return True

    finally:
        if sftp is not None:
            try:
                sftp.close()
                logging.info("SFTP session closed.")
            except Exception:
                pass
        client.close()


# -----------------------------
# CSV helpers
# -----------------------------


def export_records_to_csv(records: list[ClassRecord], output_path: str) -> str:
    """Write the current schedule table to a CSV file."""
    if not records:
        raise RuntimeError("There are no records to export.")

    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)

    with output.open("w", newline="", encoding="utf-8") as file_obj:
        writer = csv.DictWriter(file_obj, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        for record in records:
            writer.writerow(record.to_csv_row())

    return str(output)



def import_records_from_csv(csv_path: str) -> list[ClassRecord]:
    """Load an existing CSV so the schedule can be resumed or edited later."""
    loaded: list[ClassRecord] = []
    with open(csv_path, "r", newline="", encoding="utf-8-sig") as file_obj:
        reader = csv.DictReader(file_obj)
        for row in reader:
            loaded.append(ClassRecord.from_csv_row(row))
    return loaded


# -----------------------------
# Logging bridge for the UI
# -----------------------------


class QueueLogHandler(logging.Handler):
    """Push log messages into a queue so the Tkinter UI can display them safely."""

    def __init__(self, log_queue: queue.Queue[str]) -> None:
        super().__init__()
        self.log_queue = log_queue
        self.setFormatter(logging.Formatter("%(asctime)s  %(levelname)s  %(message)s"))

    def emit(self, record: logging.LogRecord) -> None:
        try:
            self.log_queue.put(self.format(record))
        except Exception:
            pass


# -----------------------------
# Tkinter application
# -----------------------------


class ClassSchedulerApp(tk.Tk):
    """Main desktop application window."""

    def __init__(self) -> None:
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1300x860")
        self.minsize(1100, 760)

        self.config_data = AppConfig.load()
        self.records: list[ClassRecord] = []
        self.selected_row_index: Optional[int] = None
        self.log_queue: queue.Queue[str] = queue.Queue()

        self._configure_theme()
        self._configure_logging()
        self._build_variables()
        self._build_ui()
        self._load_config_into_fields()
        self._poll_log_queue()

    # ----- Window setup -----

    def _configure_theme(self) -> None:
        self.style = ttk.Style(self)
        try:
            self.style.theme_use("clam")
        except tk.TclError:
            pass

        self.style.configure("Title.TLabel", font=("Segoe UI", 16, "bold"))
        self.style.configure("Section.TLabelframe.Label", font=("Segoe UI", 11, "bold"))
        self.style.configure("Treeview", rowheight=28)
        self.style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"))

    def _configure_logging(self) -> None:
        root_logger = logging.getLogger()
        root_logger.setLevel(logging.INFO)

        # Avoid duplicating our UI handler if the file is reloaded.
        already_attached = any(isinstance(h, QueueLogHandler) for h in root_logger.handlers)
        if not already_attached:
            root_logger.addHandler(QueueLogHandler(self.log_queue))

    def _build_variables(self) -> None:
        # Parser / record fields
        self.email_var = tk.StringVar()
        self.first_name_var = tk.StringVar()
        self.middle_initial_var = tk.StringVar()
        self.last_name_var = tk.StringVar()
        self.phone_var = tk.StringVar()
        self.course_var = tk.StringVar()
        self.date_var = tk.StringVar()
        self.acuity_var = tk.StringVar(value="YES")

        # CSV settings
        self.output_dir_var = tk.StringVar()
        self.csv_filename_var = tk.StringVar()

        # SFTP settings
        self.sftp_host_var = tk.StringVar()
        self.sftp_port_var = tk.StringVar(value="22")
        self.sftp_username_var = tk.StringVar()
        self.sftp_password_var = tk.StringVar()
        self.sftp_remote_dir_var = tk.StringVar()
        self.sftp_keyring_service_var = tk.StringVar()
        self.upload_file_var = tk.StringVar()
        self.verify_size_var = tk.BooleanVar(value=True)
        self.verify_sha256_var = tk.BooleanVar(value=False)
        self.auto_add_hostkey_var = tk.BooleanVar(value=False)

        # Status line
        self.status_var = tk.StringVar(value="Ready")

    def _build_ui(self) -> None:
        outer = ttk.Frame(self, padding=14)
        outer.pack(fill="both", expand=True)

        ttk.Label(outer, text=APP_TITLE, style="Title.TLabel").pack(anchor="w", pady=(0, 10))

        notebook = ttk.Notebook(outer)
        notebook.pack(fill="both", expand=True)

        schedule_tab = ttk.Frame(notebook, padding=10)
        upload_tab = ttk.Frame(notebook, padding=10)
        notebook.add(schedule_tab, text="Scheduler")
        notebook.add(upload_tab, text="SFTP Upload")

        self._build_scheduler_tab(schedule_tab)
        self._build_upload_tab(upload_tab)

        status_bar = ttk.Label(
            outer,
            textvariable=self.status_var,
            anchor="w",
            relief="sunken",
            padding=(8, 6),
        )
        status_bar.pack(fill="x", pady=(10, 0))

    # ----- Scheduler tab -----

    def _build_scheduler_tab(self, parent: ttk.Frame) -> None:
        parent.columnconfigure(0, weight=1)
        parent.rowconfigure(1, weight=1)

        top = ttk.Frame(parent)
        top.grid(row=0, column=0, sticky="nsew", pady=(0, 10))
        top.columnconfigure(0, weight=3)
        top.columnconfigure(1, weight=2)

        # Left side: raw email input and parse actions
        parse_frame = ttk.LabelFrame(top, text="Paste Acuity admin email", style="Section.TLabelframe")
        parse_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        parse_frame.columnconfigure(0, weight=1)
        parse_frame.rowconfigure(1, weight=1)

        ttk.Label(
            parse_frame,
            text="Paste the full appointment email body here. The parser will pull name, phone, email, course, and date.",
            wraplength=640,
        ).grid(row=0, column=0, sticky="w", padx=10, pady=(10, 6))

        self.email_body_text = ScrolledText(parse_frame, height=14, wrap="word")
        self.email_body_text.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 10))

        parse_button_row = ttk.Frame(parse_frame)
        parse_button_row.grid(row=2, column=0, sticky="ew", padx=10, pady=(0, 10))
        ttk.Button(parse_button_row, text="Parse email", command=self.parse_email_into_form).pack(side="left")
        ttk.Button(parse_button_row, text="Clear pasted email", command=self.clear_email_body).pack(side="left", padx=8)

        # Right side: editable record form
        form_frame = ttk.LabelFrame(top, text="Registration details", style="Section.TLabelframe")
        form_frame.grid(row=0, column=1, sticky="nsew")
        form_frame.columnconfigure(1, weight=1)

        self._add_labeled_entry(form_frame, "Email", self.email_var, 0)
        self._add_labeled_entry(form_frame, "First name", self.first_name_var, 1)
        self._add_labeled_entry(form_frame, "Middle initial", self.middle_initial_var, 2)
        self._add_labeled_entry(form_frame, "Last name", self.last_name_var, 3)
        self._add_labeled_entry(form_frame, "Phone", self.phone_var, 4)
        self._add_labeled_combobox(form_frame, "Course", self.course_var, COURSE_OPTIONS, 5)
        self._add_labeled_entry(form_frame, "Date", self.date_var, 6)
        self._add_labeled_combobox(form_frame, "Acuity registered", self.acuity_var, BOOLEAN_OPTIONS, 7)

        form_button_row = ttk.Frame(form_frame)
        form_button_row.grid(row=8, column=0, columnspan=2, sticky="ew", padx=10, pady=(6, 12))
        ttk.Button(form_button_row, text="Add record", command=self.add_record_from_form).pack(side="left")
        ttk.Button(form_button_row, text="Update selected", command=self.update_selected_record).pack(side="left", padx=8)
        ttk.Button(form_button_row, text="Clear form", command=self.clear_form).pack(side="left")

        # Bottom: schedule table + CSV actions
        bottom = ttk.LabelFrame(parent, text="Class schedule", style="Section.TLabelframe")
        bottom.grid(row=1, column=0, sticky="nsew")
        bottom.columnconfigure(0, weight=1)
        bottom.rowconfigure(1, weight=1)

        csv_controls = ttk.Frame(bottom)
        csv_controls.grid(row=0, column=0, sticky="ew", padx=10, pady=(10, 8))
        csv_controls.columnconfigure(1, weight=1)
        csv_controls.columnconfigure(3, weight=1)

        ttk.Label(csv_controls, text="Output folder").grid(row=0, column=0, sticky="w", padx=(0, 8))
        ttk.Entry(csv_controls, textvariable=self.output_dir_var).grid(row=0, column=1, sticky="ew")
        ttk.Button(csv_controls, text="Browse", command=self.choose_output_dir).grid(row=0, column=2, padx=8)

        ttk.Label(csv_controls, text="CSV filename").grid(row=0, column=3, sticky="w", padx=(18, 8))
        ttk.Entry(csv_controls, textvariable=self.csv_filename_var, width=28).grid(row=0, column=4, sticky="ew")

        csv_button_row = ttk.Frame(bottom)
        csv_button_row.grid(row=2, column=0, sticky="ew", padx=10, pady=(8, 10))
        ttk.Button(csv_button_row, text="Delete selected", command=self.delete_selected_record).pack(side="left")
        ttk.Button(csv_button_row, text="Load CSV", command=self.load_csv_into_table).pack(side="left", padx=8)
        ttk.Button(csv_button_row, text="Export CSV", command=self.export_csv_and_set_upload_file).pack(side="left")
        ttk.Button(csv_button_row, text="Clear schedule", command=self.clear_all_records).pack(side="left", padx=8)

        columns = (
            "EMAIL",
            "First Name",
            "M",
            "Last Name",
            "Phone",
            "Course",
            "Date",
            "Acuity Regist.",
        )
        self.tree = ttk.Treeview(bottom, columns=columns, show="headings", selectmode="browse")
        self.tree.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 0))
        self.tree.bind("<<TreeviewSelect>>", self.on_tree_select)
        self.tree.bind("<Double-1>", self.on_tree_double_click)

        column_widths = {
            "EMAIL": 220,
            "First Name": 110,
            "M": 45,
            "Last Name": 120,
            "Phone": 130,
            "Course": 80,
            "Date": 90,
            "Acuity Regist.": 110,
        }
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=column_widths[col], anchor="w")

        tree_scroll = ttk.Scrollbar(bottom, orient="vertical", command=self.tree.yview)
        tree_scroll.grid(row=1, column=1, sticky="ns", pady=(0, 0))
        self.tree.configure(yscrollcommand=tree_scroll.set)

    # ----- Upload tab -----

    def _build_upload_tab(self, parent: ttk.Frame) -> None:
        parent.columnconfigure(0, weight=1)
        parent.rowconfigure(1, weight=1)

        settings = ttk.LabelFrame(parent, text="SFTP settings", style="Section.TLabelframe")
        settings.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        for idx in range(4):
            settings.columnconfigure(idx, weight=1)

        self._add_labeled_entry(settings, "Host", self.sftp_host_var, 0, column_group=0)
        self._add_labeled_entry(settings, "Port", self.sftp_port_var, 0, column_group=2)
        self._add_labeled_entry(settings, "Username", self.sftp_username_var, 1, column_group=0)
        self._add_labeled_entry(settings, "Remote dir", self.sftp_remote_dir_var, 1, column_group=2)
        self._add_labeled_entry(settings, "Keyring service", self.sftp_keyring_service_var, 2, column_group=0)
        self._add_labeled_entry(settings, "Password (optional)", self.sftp_password_var, 2, column_group=2, show="*")

        options_row = ttk.Frame(settings)
        options_row.grid(row=3, column=0, columnspan=4, sticky="ew", padx=10, pady=(4, 8))
        ttk.Checkbutton(options_row, text="Verify size", variable=self.verify_size_var).pack(side="left")
        ttk.Checkbutton(options_row, text="Verify SHA256", variable=self.verify_sha256_var).pack(side="left", padx=12)
        ttk.Checkbutton(options_row, text="Auto-add host key", variable=self.auto_add_hostkey_var).pack(side="left")

        upload_controls = ttk.Frame(settings)
        upload_controls.grid(row=4, column=0, columnspan=4, sticky="ew", padx=10, pady=(0, 12))
        ttk.Button(upload_controls, text="Save settings", command=self.save_config_from_fields).pack(side="left")
        ttk.Button(upload_controls, text="Store password in keyring", command=self.store_password_in_keyring).pack(side="left", padx=8)
        ttk.Button(upload_controls, text="Upload selected CSV", command=self.start_upload).pack(side="left")

        file_frame = ttk.LabelFrame(parent, text="File to upload", style="Section.TLabelframe")
        file_frame.grid(row=1, column=0, sticky="nsew")
        file_frame.columnconfigure(1, weight=1)
        file_frame.rowconfigure(1, weight=1)

        ttk.Label(
            file_frame,
            text="Export a CSV from the Scheduler tab, or browse to an existing file. The uploader sends the exact file name shown here.",
            wraplength=980,
        ).grid(row=0, column=0, columnspan=3, sticky="w", padx=10, pady=(10, 8))

        ttk.Label(file_frame, text="CSV path").grid(row=1, column=0, sticky="w", padx=(10, 8), pady=(0, 10))
        ttk.Entry(file_frame, textvariable=self.upload_file_var).grid(row=1, column=1, sticky="ew", pady=(0, 10))
        ttk.Button(file_frame, text="Browse", command=self.choose_upload_file).grid(row=1, column=2, padx=10, pady=(0, 10))

        log_frame = ttk.LabelFrame(parent, text="Upload log", style="Section.TLabelframe")
        log_frame.grid(row=2, column=0, sticky="nsew")
        log_frame.columnconfigure(0, weight=1)
        log_frame.rowconfigure(0, weight=1)
        self.log_text = ScrolledText(log_frame, height=18, wrap="word", state="disabled")
        self.log_text.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)

    # ----- Small widget builders -----

    def _add_labeled_entry(
        self,
        parent: ttk.Widget,
        label_text: str,
        variable: tk.StringVar,
        row: int,
        column_group: int = 0,
        show: Optional[str] = None,
    ) -> None:
        col = column_group
        ttk.Label(parent, text=label_text).grid(row=row, column=col, sticky="w", padx=10, pady=6)
        ttk.Entry(parent, textvariable=variable, show=show).grid(
            row=row,
            column=col + 1,
            sticky="ew",
            padx=(0, 10),
            pady=6,
        )

    def _add_labeled_combobox(
        self,
        parent: ttk.Widget,
        label_text: str,
        variable: tk.StringVar,
        values: list[str],
        row: int,
    ) -> None:
        ttk.Label(parent, text=label_text).grid(row=row, column=0, sticky="w", padx=10, pady=6)
        box = ttk.Combobox(parent, textvariable=variable, values=values, state="readonly")
        box.grid(row=row, column=1, sticky="ew", padx=(0, 10), pady=6)

    # ----- Config handling -----

    def _load_config_into_fields(self) -> None:
        self.output_dir_var.set(self.config_data.output_dir)
        self.csv_filename_var.set(self.config_data.csv_filename)
        self.sftp_host_var.set(self.config_data.sftp_host)
        self.sftp_port_var.set(str(self.config_data.sftp_port))
        self.sftp_username_var.set(self.config_data.sftp_username)
        self.sftp_remote_dir_var.set(self.config_data.sftp_remote_dir)
        self.sftp_keyring_service_var.set(self.config_data.sftp_keyring_service)
        self.verify_size_var.set(self.config_data.verify_size)
        self.verify_sha256_var.set(self.config_data.verify_sha256)
        self.auto_add_hostkey_var.set(self.config_data.auto_add_hostkey)
        self.upload_file_var.set(self.config_data.last_upload_file)

    def save_config_from_fields(self) -> None:
        self.config_data.output_dir = self.output_dir_var.get().strip() or str(Path.home())
        self.config_data.csv_filename = self.csv_filename_var.get().strip() or "class_schedule.csv"
        self.config_data.sftp_host = self.sftp_host_var.get().strip()
        self.config_data.sftp_port = self._safe_int(self.sftp_port_var.get().strip(), default=22)
        self.config_data.sftp_username = self.sftp_username_var.get().strip()
        self.config_data.sftp_remote_dir = self.sftp_remote_dir_var.get().strip() or "/"
        self.config_data.sftp_keyring_service = self.sftp_keyring_service_var.get().strip() or "rqi-sftp"
        self.config_data.verify_size = self.verify_size_var.get()
        self.config_data.verify_sha256 = self.verify_sha256_var.get()
        self.config_data.auto_add_hostkey = self.auto_add_hostkey_var.get()
        self.config_data.last_upload_file = self.upload_file_var.get().strip()
        self.config_data.save()
        self.set_status(f"Settings saved to {APP_CONFIG_PATH}")

    # ----- Scheduler actions -----

    def parse_email_into_form(self) -> None:
        raw_email = self.email_body_text.get("1.0", "end").strip()
        if not raw_email:
            messagebox.showwarning("No email pasted", "Paste an Acuity email body before parsing.")
            return

        record = scrape_acuity_admin_fields(raw_email)
        self._populate_form(record)

        missing = []
        if not record.email:
            missing.append("email")
        if not record.first_name and not record.last_name:
            missing.append("name")
        if not record.course:
            missing.append("course")
        if not record.date:
            missing.append("date")

        if missing:
            self.set_status(f"Parsed with missing fields: {', '.join(missing)}")
        else:
            self.set_status("Email parsed successfully")

    def clear_email_body(self) -> None:
        self.email_body_text.delete("1.0", "end")
        self.set_status("Pasted email cleared")

    def clear_form(self) -> None:
        self.selected_row_index = None
        self.email_var.set("")
        self.first_name_var.set("")
        self.middle_initial_var.set("")
        self.last_name_var.set("")
        self.phone_var.set("")
        self.course_var.set("")
        self.date_var.set("")
        self.acuity_var.set("YES")
        self.set_status("Form cleared")

    def _populate_form(self, record: ClassRecord) -> None:
        self.email_var.set(record.email)
        self.first_name_var.set(record.first_name)
        self.middle_initial_var.set(record.middle_initial)
        self.last_name_var.set(record.last_name)
        self.phone_var.set(record.phone)
        self.course_var.set(record.course)
        self.date_var.set(record.date)
        self.acuity_var.set(record.acuity_registered or "YES")

    def _record_from_form(self) -> ClassRecord:
        return ClassRecord(
            email=self.email_var.get().strip(),
            first_name=self.first_name_var.get().strip(),
            middle_initial=self.middle_initial_var.get().strip()[:1],
            last_name=self.last_name_var.get().strip(),
            phone=self.phone_var.get().strip(),
            course=self.course_var.get().strip(),
            date=self.date_var.get().strip(),
            acuity_registered=self.acuity_var.get().strip() or "YES",
        )

    def add_record_from_form(self) -> None:
        record = self._record_from_form()
        if not self._validate_record(record):
            return

        self.records.append(record)
        self._refresh_tree()
        self.clear_form()
        self.set_status(f"Added record for {record.first_name} {record.last_name}".strip())

    def update_selected_record(self) -> None:
        if self.selected_row_index is None or not (0 <= self.selected_row_index < len(self.records)):
            messagebox.showwarning("No selection", "Select a row in the schedule table to update it.")
            return

        record = self._record_from_form()
        if not self._validate_record(record):
            return

        self.records[self.selected_row_index] = record
        self._refresh_tree(select_index=self.selected_row_index)
        self.set_status("Selected record updated")

    def delete_selected_record(self) -> None:
        if self.selected_row_index is None or not (0 <= self.selected_row_index < len(self.records)):
            messagebox.showwarning("No selection", "Select a row to delete.")
            return

        record = self.records[self.selected_row_index]
        if not messagebox.askyesno(
            "Delete record",
            f"Delete the record for {record.first_name} {record.last_name}?",
        ):
            return

        del self.records[self.selected_row_index]
        self.selected_row_index = None
        self._refresh_tree()
        self.clear_form()
        self.set_status("Selected record deleted")

    def clear_all_records(self) -> None:
        if not self.records:
            return

        if not messagebox.askyesno("Clear schedule", "Remove every record from the current schedule?"):
            return

        self.records.clear()
        self.selected_row_index = None
        self._refresh_tree()
        self.clear_form()
        self.set_status("Schedule cleared")

    def load_csv_into_table(self) -> None:
        path = filedialog.askopenfilename(
            title="Load schedule CSV",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
        )
        if not path:
            return

        try:
            self.records = import_records_from_csv(path)
            self._refresh_tree()
            self.output_dir_var.set(str(Path(path).parent))
            self.csv_filename_var.set(Path(path).name)
            self.upload_file_var.set(path)
            self.save_config_from_fields()
            self.set_status(f"Loaded {len(self.records)} records from CSV")
        except Exception as exc:
            messagebox.showerror("CSV load failed", str(exc))

    def export_csv_and_set_upload_file(self) -> None:
        try:
            self.save_config_from_fields()
            output_path = str(Path(self.output_dir_var.get().strip()) / self.csv_filename_var.get().strip())
            exported = export_records_to_csv(self.records, output_path)
            self.upload_file_var.set(exported)
            self.save_config_from_fields()
            self.set_status(f"CSV exported to {exported}")
            messagebox.showinfo("Export complete", f"CSV exported successfully:\n\n{exported}")
        except Exception as exc:
            messagebox.showerror("CSV export failed", str(exc))

    def _validate_record(self, record: ClassRecord) -> bool:
        missing = []
        if not record.email:
            missing.append("Email")
        if not record.first_name:
            missing.append("First Name")
        if not record.last_name:
            missing.append("Last Name")
        if not record.course:
            missing.append("Course")
        if not record.date:
            missing.append("Date")

        if missing:
            messagebox.showwarning(
                "Missing required fields",
                "Please fill these fields before saving the record:\n\n" + ", ".join(missing),
            )
            return False
        return True

    def _refresh_tree(self, select_index: Optional[int] = None) -> None:
        for item_id in self.tree.get_children():
            self.tree.delete(item_id)

        for index, record in enumerate(self.records):
            item_id = str(index)
            self.tree.insert(
                "",
                "end",
                iid=item_id,
                values=(
                    record.email,
                    record.first_name,
                    record.middle_initial,
                    record.last_name,
                    record.phone,
                    record.course,
                    record.date,
                    record.acuity_registered,
                ),
            )

        if select_index is not None and 0 <= select_index < len(self.records):
            item_id = str(select_index)
            self.tree.selection_set(item_id)
            self.tree.focus(item_id)
            self.tree.see(item_id)
            self.selected_row_index = select_index

    def on_tree_select(self, _event=None) -> None:
        selection = self.tree.selection()
        if not selection:
            self.selected_row_index = None
            return

        index = int(selection[0])
        self.selected_row_index = index
        self._populate_form(self.records[index])

    def on_tree_double_click(self, _event=None) -> None:
        self.on_tree_select()
        self.set_status("Loaded selected row into the form")

    # ----- Upload actions -----

    def choose_output_dir(self) -> None:
        path = filedialog.askdirectory(title="Choose export folder")
        if path:
            self.output_dir_var.set(path)

    def choose_upload_file(self) -> None:
        path = filedialog.askopenfilename(
            title="Choose CSV to upload",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
        )
        if path:
            self.upload_file_var.set(path)
            self.save_config_from_fields()

    def store_password_in_keyring(self) -> None:
        username = self.sftp_username_var.get().strip()
        service = self.sftp_keyring_service_var.get().strip() or "rqi-sftp"
        password = self.sftp_password_var.get()

        if keyring is None:
            messagebox.showerror(
                "Keyring unavailable",
                "The 'keyring' package is not installed. Install it to store passwords in the OS keychain.",
            )
            return

        if not username or not password:
            messagebox.showwarning(
                "Missing values",
                "Enter both a username and a password before storing the password in keyring.",
            )
            return

        try:
            keyring.set_password(service, username, password)
            self.set_status(f"Password stored in keyring for {username}")
            messagebox.showinfo("Keyring updated", "Password saved to your OS keyring successfully.")
        except Exception as exc:
            messagebox.showerror("Keyring error", str(exc))

    def start_upload(self) -> None:
        self.save_config_from_fields()

        settings = {
            "local_path": self.upload_file_var.get().strip(),
            "host": self.sftp_host_var.get().strip(),
            "port": self._safe_int(self.sftp_port_var.get().strip(), default=22),
            "username": self.sftp_username_var.get().strip(),
            "password": self.sftp_password_var.get(),
            "remote_dir": self.sftp_remote_dir_var.get().strip(),
            "keyring_service": self.sftp_keyring_service_var.get().strip() or "rqi-sftp",
            "verify_sha256": self.verify_sha256_var.get(),
            "verify_size": self.verify_size_var.get(),
            "auto_add_host_key": self.auto_add_hostkey_var.get(),
        }

        missing = []
        if not settings["local_path"]:
            missing.append("CSV path")
        if not settings["host"]:
            missing.append("Host")
        if not settings["username"]:
            missing.append("Username")
        if not settings["remote_dir"]:
            missing.append("Remote dir")

        if missing:
            messagebox.showwarning(
                "Missing upload settings",
                "Please complete these values before uploading:\n\n" + ", ".join(missing),
            )
            return

        if not os.path.isfile(settings["local_path"]):
            messagebox.showerror(
                "Missing file",
                f"The file does not exist:\n\n{settings['local_path']}",
            )
            return

        # Run the network upload in a background thread so the UI stays responsive.
        worker = threading.Thread(target=self._upload_worker, args=(settings,), daemon=True)
        worker.start()
        self.set_status("Upload started")

    def _upload_worker(self, settings: dict[str, object]) -> None:
        try:
            username = str(settings["username"])
            password = resolve_password(
                username=username,
                cli_password=str(settings["password"]),
                keyring_service=str(settings["keyring_service"]),
            )
            local_path = str(settings["local_path"])

            ok = upload_file_with_password(
                host=str(settings["host"]),
                port=int(settings["port"]),
                username=username,
                password=password,
                local_path=local_path,
                remote_dir=str(settings["remote_dir"]) or "/",
                verify_sha256=bool(settings["verify_sha256"]),
                verify_size=bool(settings["verify_size"]),
                auto_add_host_key=bool(settings["auto_add_host_key"]),
            )
            if ok:
                self.after(0, lambda: self._on_upload_success(local_path))
        except Exception as exc:
            logging.exception("Upload failed: %s", exc)
            self.after(0, lambda: messagebox.showerror("Upload failed", str(exc)))
            self.after(0, lambda: self.set_status("Upload failed"))

    def _on_upload_success(self, local_path: str) -> None:
        self.set_status("Upload completed successfully")
        messagebox.showinfo("Upload complete", f"Upload completed successfully:\n\n{local_path}")

    # ----- Utility helpers -----

    def _poll_log_queue(self) -> None:
        try:
            while True:
                message = self.log_queue.get_nowait()
                self.log_text.configure(state="normal")
                self.log_text.insert("end", message + "\n")
                self.log_text.see("end")
                self.log_text.configure(state="disabled")
        except queue.Empty:
            pass

        self.after(150, self._poll_log_queue)

    def set_status(self, message: str) -> None:
        self.status_var.set(message)

    @staticmethod
    def _safe_int(value: str, default: int) -> int:
        try:
            return int(value)
        except (TypeError, ValueError):
            return default


def main() -> None:
    app = ClassSchedulerApp()
    app.mainloop()


if __name__ == "__main__":
    main()
